<?php
include 'config/db.php';
include 'auth.php';

// Ambil data kategori
$kategori = $conn->query("SELECT * FROM categories")->fetchAll(PDO::FETCH_ASSOC);

// Ambil data produk
$produk = $conn->query("SELECT * FROM products ORDER BY created_at DESC")->fetchAll(PDO::FETCH_ASSOC);

// Ambil data order jika login
$orders = [];
if (isLoggedIn()) {
    $user_id = $_SESSION['user']['user_id'];
    $ordersQuery = $conn->prepare("SELECT * FROM orders WHERE user_id = ?");
    $ordersQuery->execute([$user_id]);
    $orders = $ordersQuery->fetchAll(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dashboard - E-Commerce</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f4f4f4;
        }
        header {
            background-color: #3b5998;
            padding: 10px 20px;
            color: white;
        }
        nav {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        nav ul {
            list-style: none;
            display: flex;
            gap: 20px;
            margin: 0;
            padding: 0;
        }
        nav ul li a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .container {
            display: grid;
            grid-template-columns: 220px 1fr;
            gap: 20px;
            padding: 20px;
        }

        .box {
            background: white;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 20px;
        }

        .banner {
            height: 180px;
            background: #ddd;
            border-radius: 8px;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 28px;
            font-weight: bold;
            color: #333;
        }

        .product-grid {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
        }

        .product-card {
            width: 180px;
            background: #f9f9f9;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 6px;
            text-align: center;
        }

        .product-card img {
            width: 100%;
            height: 120px;
            object-fit: cover;
        }

        .add-btn {
            background-color: #3b5998;
            color: white;
            border: none;
            padding: 8px;
            margin-top: 8px;
            border-radius: 4px;
            cursor: pointer;
        }

        .add-btn:hover {
            background-color: #2e467f;
        }

        .review {
            margin-top: 15px;
            border-top: 1px solid #ccc;
            padding-top: 10px;
        }

        .star {
            color: gold;
        }
    </style>
</head>
<body>

<header>
    <nav>
        <div><strong>E-COMMERCE</strong></div>
        <ul>
            <li><a href="#">Home</a></li>
            <li><a href="#">Products</a></li>
            <?php if (isLoggedIn()): ?>
                <li><a href="#">Orders</a></li>
                <li><a href="#">Cart</a></li>
                <li><a href="#">Account</a></li>
            <?php else: ?>
                <li><a href="login.php">Login</a></li>
                <li><a href="register.php">Register</a></li>
            <?php endif; ?>
        </ul>
    </nav>
</header>

<div class="container">
    <!-- Sidebar -->
    <div>
        <div class="box">
            <h3>Categories</h3>
            <ul>
                <?php foreach ($kategori as $k): ?>
                    <li><?= htmlspecialchars($k['name']) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>

        <div class="box">
            <h3>Orders</h3>
            <?php if (isLoggedIn() && !empty($orders)): ?>
                <ul>
                    <?php foreach ($orders as $order): ?>
                        <li>#<?= $order['order_id'] ?> - <?= $order['status'] ?></li>
                    <?php endforeach; ?>
                </ul>
            <?php elseif (isLoggedIn()): ?>
                <p>No orders found.</p>
            <?php else: ?>
                <p>Login to see your orders.</p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Main Content -->
    <div>
        <div class="banner">Shop Now</div>

        <div class="box">
            <h3>Featured Products</h3>
            <div class="product-grid">
                <?php foreach ($produk as $p): ?>
                    <div class="product-card">
                        <img src="assets/images/<?= htmlspecialchars($p['image_url']) ?>" alt="<?= htmlspecialchars($p['name']) ?>">
                        <div><strong><?= htmlspecialchars($p['name']) ?></strong></div>
                        <div>Rp <?= number_format($p['price'], 0, ',', '.') ?></div>
                        <?php if (isLoggedIn()): ?>
                            <form method="post" action="add_to_cart.php">
                                <input type="hidden" name="product_id" value="<?= $p['product_id'] ?>">
                                <button type="submit" class="add-btn">Add to Cart</button>
                            </form>
                        <?php else: ?>
                            <a href="login.php"><button class="add-btn">Beli</button></a>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="box review">
            <h3>Reviews</h3>
            <p>User A: Produk bagus banget!</p>
            <p>User B: Harga oke, kualitas mantap ⭐⭐⭐⭐⭐</p>
        </div>
    </div>
</div>

</body>
</html>
