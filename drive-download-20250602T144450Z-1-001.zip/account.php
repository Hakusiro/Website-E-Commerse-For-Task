<?php
include 'config/db.php';
include 'auth.php';

if (!isLoggedIn()) {
    header("Location: login.php");
    exit;
}

$user = $_SESSION['user'];

// Ambil riwayat pesanan user
$stmt = $conn->prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY order_date DESC");
$stmt->execute([$user['user_id']]);
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Ambil rekomendasi produk (sederhana: semua produk)
$rekomendasi = $conn->query("SELECT * FROM products ORDER BY created_at DESC LIMIT 4")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Akun Pelanggan</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            background: #f4f4f4;
        }

        header {
            background: #3b5998;
            color: white;
            padding: 10px 20px;
        }

        .container {
            display: grid;
            grid-template-columns: 220px 1fr;
            gap: 20px;
            padding: 20px;
        }

        .sidebar {
            background: white;
            border-radius: 8px;
            padding: 20px;
        }

        .sidebar h3 {
            margin-top: 0;
        }

        .sidebar ul {
            list-style: none;
            padding: 0;
        }

        .sidebar ul li {
            margin: 10px 0;
        }

        .sidebar ul li a {
            text-decoration: none;
            color: #3b5998;
            font-weight: bold;
        }

        .main-content {
            background: white;
            border-radius: 8px;
            padding: 20px;
        }

        .section {
            margin-bottom: 30px;
        }

        .section h3 {
            border-bottom: 1px solid #ccc;
            padding-bottom: 8px;
        }

        .order {
            margin-bottom: 10px;
            padding: 10px;
            background: #f8f8f8;
            border-left: 4px solid #3b5998;
        }

        .product-grid {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
        }

        .product-card {
            width: 180px;
            background: #f9f9f9;
            border: 1px solid #ccc;
            padding: 10px;
            border-radius: 6px;
            text-align: center;
        }

        .product-card img {
            width: 100%;
            height: 120px;
            object-fit: cover;
        }

        .add-btn {
            background-color: #3b5998;
            color: white;
            border: none;
            padding: 6px 10px;
            margin-top: 8px;
            border-radius: 4px;
            cursor: pointer;
        }

        .add-btn:hover {
            background-color: #2e467f;
        }
    </style>
</head>
<body>

<header>
    <h2>Akun Pelanggan: <?= htmlspecialchars($user['name']) ?></h2>
</header>

<div class="container">
    <!-- Sidebar -->
    <div class="sidebar">
        <h3>Menu Akun</h3>
        <ul>
            <li><a href="#">Riwayat Pesanan</a></li>
            <li><a href="#">Ulasan</a></li>
            <li><a href="#">Pengaturan Akun</a></li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Status Pemesanan -->
        <div class="section">
            <h3>Status Pemesanan</h3>
            <?php if (!empty($orders)): ?>
                <?php foreach ($orders as $order): ?>
                    <div class="order">
                        <strong>Order #<?= $order['order_id'] ?></strong> - Status: <?= $order['status'] ?> <br>
                        Total: Rp <?= number_format($order['total_price'], 0, ',', '.') ?> <br>
                        Tanggal: <?= $order['order_date'] ?>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>Belum ada pesanan.</p>
            <?php endif; ?>
        </div>

        <!-- Rekomendasi Produk -->
        <div class="section">
            <h3>Rekomendasi Produk</h3>
            <div class="product-grid">
                <?php foreach ($rekomendasi as $p): ?>
                    <div class="product-card">
                        <img src="assets/images/<?= htmlspecialchars($p['image_url']) ?>" alt="<?= htmlspecialchars($p['name']) ?>">
                        <div><strong><?= htmlspecialchars($p['name']) ?></strong></div>
                        <div>Rp <?= number_format($p['price'], 0, ',', '.') ?></div>
                        <form method="post" action="add_to_cart.php">
                            <input type="hidden" name="product_id" value="<?= $p['product_id'] ?>">
                            <button type="submit" class="add-btn">Tambah ke Keranjang</button>
                        </form>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>

</body>
</html>
